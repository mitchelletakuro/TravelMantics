package com.novatech.travelmantics;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminActivity extends AppCompatActivity {
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;
    EditText editTxtTitle;
    EditText editTxtDescription;
    EditText editTxtPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        mFirebaseDatabase =FirebaseDatabase.getInstance();
        mDatabaseReference=mFirebaseDatabase.getReference().child("traveldeals");
        editTxtTitle = findViewById(R.id.et_title);
        editTxtDescription =findViewById(R.id.et_description);
        editTxtPrice =findViewById(R.id.et_price);
}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case  R.id.save_menu:
                saveDeal();
                Toast.makeText(this,"Deal Saved",Toast.LENGTH_LONG).show();
                clean();
                return  true;
                default:
                    return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
     MenuInflater inflater = getMenuInflater();
     inflater.inflate(R.menu.save_menu,menu);
     return true;

    }

    private  void saveDeal(){
        String title =editTxtTitle.getText().toString();
        String description =editTxtDescription.getText().toString();
        String price =editTxtPrice.getText().toString();
        TravelDeal deal = new TravelDeal(title,description,price,"");
        mDatabaseReference.push().setValue(deal);

    }
    private void clean (){
        editTxtTitle.setText("");
        editTxtDescription.setText("");
        editTxtPrice.setText("");
        editTxtTitle.requestFocus();
    }


}
