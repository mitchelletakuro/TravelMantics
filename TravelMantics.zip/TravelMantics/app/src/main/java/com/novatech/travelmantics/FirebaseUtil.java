package com.novatech.travelmantics;

public class FirebaseUtil {
        private static final int RC_SIGN_IN = 6009;
        public static FirebaseDatabase mFirebaseDb;
        public static DatabaseReference mDbReference;
        private static FirebaseUtil firebaseUtil;
        public static FirebaseAuth mFirebaseAuth;
        public static FirebaseAuth.AuthStateListener mAuthListener;
        public static FirebaseStorage mStorage;
        public static StorageReference mStorageRef;
        public static ArrayList<TravelDeal> mDeals;
        private static UserActivity caller;
        public static boolean isAdmin;

        public FirebaseUtil() {
        }

        // Configuring offline persistence
        public static FirebaseDatabase getDatabase() {
            if (mFirebaseDb == null) {
                mFirebaseDb = FirebaseDatabase.getInstance();
                mFirebaseDb.setPersistenceEnabled(true);
            }
            return mFirebaseDb;
        }

        public static void openFirebaseRef(String ref, UserActivity callerActivity) {
            if (firebaseUtil == null) {
                firebaseUtil = new FirebaseUtil();
                mFirebaseDb = FirebaseDatabase.getInstance();
                caller = callerActivity;

                mFirebaseAuth = FirebaseAuth.getInstance();
                mAuthListener = new FirebaseAuth.AuthStateListener() {
                    @Override
                    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                        if (firebaseAuth.getCurrentUser() == null) {
                            FirebaseUtil.signIn();
                        } else {
                            String userId = firebaseAuth.getUid();
                            checkAdmin(userId);
                        }
                    }
                };
                connectStorage();
            }
            mDeals = new ArrayList<>();
            mDbReference = mFirebaseDb.getReference().child(ref);
        }

        private static void signIn() {
            List<AuthUI.IdpConfig> providers = Arrays.asList(
                    new AuthUI.IdpConfig.EmailBuilder().build(),
                    new AuthUI.IdpConfig.GoogleBuilder().build());

            // Initialize sign-in intent
            caller.startActivityForResult(
                    AuthUI.getInstance()
                            .createSignInIntentBuilder()
                            .setAvailableProviders(providers)
                            .setIsSmartLockEnabled(false)
                            .build(),
                    RC_SIGN_IN);
        }

        public static void signOut() {
            AuthUI.getInstance()
                    .signOut(caller)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Log.d("Logout", "User Logged Out");
                            Toast.makeText(caller, "You've Successfully Signed Out", Toast.LENGTH_SHORT).show();
                            FirebaseUtil.attachListener();
                        }
                    });
        }

        public static void checkAdmin(String uid) {
            FirebaseUtil.isAdmin = false;
            DatabaseReference ref = mFirebaseDb.getReference()
                    .child("administrators")
                    .child(uid);

            ChildEventListener listener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    FirebaseUtil.isAdmin = true;
                    Log.d("Admin", "onChildAdded: You are an administrator");
                    //  caller.showMenu();
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            };
            ref.addChildEventListener(listener);
        }

        public static void attachListener() {
            mFirebaseAuth.addAuthStateListener(mAuthListener);
        }

        public static void detachListener() {
            mFirebaseAuth.removeAuthStateListener(mAuthListener);
        }

        public static void connectStorage() {
            mStorage = FirebaseStorage.getInstance();
            mStorageRef = mStorage.getReference().child("pictures");
        }
}
